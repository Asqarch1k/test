import { useState } from "react";
import "../style/App.css";
import Navbar from "./components/header/header";
import Hero from "./components/heroSection/hero";
import Trending from "./components/trending/trending";
import TopRated from "./components/topRated/topRated";
import Browse from "./components/browse/browse";
import Discover from "./components/discover/discover";
import NftInfo from "./components/NftInfo/NftInfo";
import HowWork from "./components/howWork/howWork";
import Footer from "./components/footer/footer";

function App() {
  return (
    <div className="container">
      <Navbar />
      <Hero />
      <Trending />
      <TopRated />
      <Browse />
      <Discover />
      <NftInfo />
      <HowWork />
      <Footer />
    </div>
  );
}

export default App;
