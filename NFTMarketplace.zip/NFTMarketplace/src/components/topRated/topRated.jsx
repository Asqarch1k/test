import React from "react";
import "./topRated.css";
import avatar1 from "../../../imgs/Artist Avatar.png";
import avatar2 from "../../../imgs/Asset 12 2.png";
import avatar3 from "../../../imgs/Asset 12 2 (1).png";
import avatar4 from "../../../imgs/Asset 12 2 (2).png";
import avatar5 from "../../../imgs/Asset 12 2 (3).png";
import avatar6 from "../../../imgs/Asset 12 2 (4).png";
import avatar7 from "../../../imgs/Asset 12 2 (5).png";
import avatar8 from "../../../imgs/Asset 12 2 (6).png";
import avatar9 from "../../../imgs/Asset 12 2 (7).png";
import avatar10 from "../../../imgs/Asset 12 2 (8).png";
import avatar11 from "../../../imgs/Asset 12 2 (9).png";
import raketa from "../../../imgs/RocketLaunch.png";
function TopRated() {
  return (
    <div className="topRatedSection">
      <div className="topSection">
        <div>
          <h1 className="TrendingText">Top creators</h1>
          <p className="Checkout">
            Checkout Top Rated Creators on the NFT Marketplace
          </p>
        </div>
        <div>
          <button className="vievRankBtn vievRankBtn1">
            <img src={raketa} alt="" />
            View Rankings
          </button>
        </div>
      </div>
      <div className="raderBoxes">
        <div className="cards">
          <div className="cardImg">
            <img src={avatar1} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar2} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar3} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar4} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar5} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar3} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar6} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar7} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar8} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar9} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar10} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
        <div className="cards">
          <div className="cardImg">
            <img src={avatar11} alt="" />
          </div>
          <div>
            <h2 className="KeepitrealText">Keepitreal</h2>
            <div style={{ display: "flex" }}>
              <p className="totalSales">Total Sales:</p>
              <p className="priseText">34.53 ETH</p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <button className="vievRankBtn vievRankBtn2">
          {" "}
          <img src={raketa} alt="" />
          View Rankings
        </button>
      </div>
    </div>
  );
}

export default TopRated;
