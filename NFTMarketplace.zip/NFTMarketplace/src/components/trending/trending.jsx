import React from "react";
import "./trending.css";
import dog1 from "../../../imgs/Primary Photo Placeholder.png";
import dog2 from "../../../imgs/Secondary Photo Placeholder (1).png";
import dog3 from "../../../imgs/Secondary Photo Placeholder.png";
import number from "../../../imgs/Number of additional NFTs.png";
import footerPhoto1 from "../../../imgs/Artist Card.png";
import footerPhoto2 from "../../../imgs/Artist Card (1).png";
import footerPhoto3 from "../../../imgs/Artist Card (2).png";
import mushroom1 from "../../../imgs/Primary Photo Placeholder (1).png";
import mushroom2 from "../../../imgs/Secondary Photo Placeholder (2).png";
import mushroom3 from "../../../imgs/Secondary Photo Placeholder (3).png";
import robot1 from "../../../imgs/Primary Photo Placeholder (2).png";
import robot2 from "../../../imgs/Secondary Photo Placeholder (4).png";
import robot3 from "../../../imgs/Secondary Photo Placeholder (5).png";

function Trending() {
  return (
    <div className="trending">
      <div>
        <h1 className="TrendingText">Trending Collection</h1>
        <p className="CheckoutText">
          Checkout our weekly updated trending collection.
        </p>
      </div>
      <div className="threeBox">
        <div>
          <div>
            <img src={dog1} alt="" />
          </div>
          <div className="threeDog">
            <img src={dog2} alt="" />
            <img src={dog3} alt="" />
            <img src={number} alt="" />
          </div>
          <h2 className="DSGNText">DSGN Animals</h2>
          <img src={footerPhoto1} alt="" />
        </div>
        <div className="secondBoxs1">
          <div>
            <img src={mushroom1} alt="" />
          </div>
          <div className="threeDog">
            <img src={mushroom2} alt="" />
            <img src={mushroom3} alt="" />
            <img src={number} alt="" />
          </div>
          <h2 className="DSGNText">Magic Mushrooms</h2>
          <img src={footerPhoto2} alt="" />
        </div>
        <div className="secondBoxs2">
          <div>
            <img src={robot1} alt="" />
          </div>
          <div className="threeDog">
            <img src={robot2} alt="" />
            <img src={robot3} alt="" />
            <img src={number} alt="" />
          </div>
          <h2 className="DSGNText">Disco Machines</h2>
          <img src={footerPhoto3} alt="" />
        </div>
      </div>
    </div>
  );
}

export default Trending;
