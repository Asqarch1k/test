import React from "react";
import "./NftInfo.css";
import Timer from "../../el/taymer/taymer";
import foto12 from "../../../imgs/Asset 12 2 (5).png";
import eyeic from "../../../imgs/Eye.png";

function NftInfo() {
  const ketmon = new Date("2024-01-01");
  return (
    <div className="InfoSection">
      {/* <div className="fotodiv">
        <img src={foto12} alt="" />
        <p className="Shroomie">Shroomie</p>
      </div> */}
      <div className="timersec">
        <div>
          <div className="fotodiv">
            <img src={foto12} alt="" />
            <p className="Shroomie">Shroomie</p>
          </div>
          <h1 className="MagicText">Magic Mashrooms</h1>
          <button className="vievRankBtn">
            <img src={eyeic} alt="" />
            See NFT
          </button>
        </div>
        <div className="timerSectiv">
          <Timer until={ketmon} />
        </div>
      </div>
    </div>
  );
}

export default NftInfo;
