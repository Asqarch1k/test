import React from "react";
import "./howWork.css";
import icon1 from "../../../imgs/Icon.png";
import icon2 from "../../../imgs/Icon (1).png";
import icon3 from "../../../imgs/Icon (2).png";
import people1 from "../../../imgs/Photo.png";

function HowWork() {
  return (
    <div className="howWorkDiv">
      <h1 className="howText">How it works</h1>
      <p className="findText">Find out how to get started</p>
      <div className="iconCardSec">
        <div className="iconCard">
          <img src={icon1} alt="" />
          <div>
            <h1 className="SetupText">Setup Your wallet</h1>
            <p className="SetUpText">
              Set up your wallet of choice. <br /> Connect it to the Animarket{" "}
              <br /> by clicking the wallet icon in the top <br /> right corner.
            </p>
          </div>
        </div>
        <div className="iconCard">
          <img src={icon2} alt="" />
          <div>
            <h1 className="SetupText">Setup Your wallet</h1>
            <p className="SetUpText">
              Set up your wallet of choice. <br /> Connect it to the Animarket{" "}
              <br /> by clicking the wallet icon in the top <br /> right corner.
            </p>
          </div>
        </div>
        <div className="iconCard">
          <img src={icon3} alt="" />
          <div>
            <h1 className="SetupText">Setup Your wallet</h1>
            <p className="SetUpText">
              Set up your wallet of choice. <br /> Connect it to the Animarket{" "}
              <br /> by clicking the wallet icon in the top <br /> right corner.
            </p>
          </div>
        </div>
      </div>
      <div className="peoplweSec">
        <div className="peopleft">
          <img src={people1} alt="" />
        </div>
        <div>
          <h1 className="JoinText">
            Join Our Weekly <br /> Digest
          </h1>
          <p className="GetText">
            Get exclusive promotions & updates <br /> straight to your inbox.
          </p>
          <div className="subscribe">
            <input
              className="inputSec"
              type="text"
              placeholder="Enter your email here Subscribe"
            />
            <button className="SubscribeBtn">Subscribe</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HowWork;
