import React, { useState } from "react";
import "../header/header.css";
import Logo from "../../../imgs/Logo.png";
import User from "../../../imgs/User.png";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleNavbar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <h1 className="navbar-logo">
          <img src={Logo} alt="" />
        </h1>
        <div
          className={`menu-icon ${isOpen ? "open" : ""}`}
          onClick={toggleNavbar}
        >
          <div className="bar" />
          <div className="bar" />
          <div className="bar" />
        </div>

        <ul className={`nav-menu ${isOpen ? "active" : ""}`}>
          <li className="nav-item">
            <a href="/">Marketplace</a>
          </li>
          <li className="nav-item">
            <a href="/about">Rankings</a>
          </li>
          <li className="nav-item" style={{ color: "red" }}>
            <a href="/services">Connect a wallet</a>
          </li>
          <button className="signUpbtn"> <img src={User} alt="" /> Sign up</button>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
