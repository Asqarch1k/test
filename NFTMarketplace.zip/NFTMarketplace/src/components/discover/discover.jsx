import React from "react";
import "./discover.css";
import eyeic from "../../../imgs/Eye.png";
import nft1 from "../../../imgs/Image Placeholder.png";
import nft2 from "../../../imgs/Image Placeholder (1).png";
import nft3 from "../../../imgs/Image Placeholder (2).png";
import avatar1 from "../../../imgs/Artist Avatar & Name.png";
import avatar2 from "../../../imgs/Artist Avatar & Name (1).png";
import avatar3 from "../../../imgs/Artist Avatar & Name (2).png";

function Discover() {
  return (
    <div className="discoverSection">
      <div className="topSection">
        <div>
          <h1 className="TrendingText">Discover More NFTs</h1>
          <p className="Checkout">Explore new trending NFTs</p>
        </div>
        <div>
          <button className="vievRankBtn vievRankBtn1">
            <img src={eyeic} alt="" />
            See All
          </button>
        </div>
      </div>
      <div className="NFTcSection">
        <div className="nftCard">
          <img src={nft1} alt="" />
          <div className="nftBot">
            <h1 className="DistantText">Distant Galaxy</h1>
            <img src={avatar1} alt="" />
            <div style={{ display: "flex", gap: "71px" }}>
              <div>
                <p className="priseText">Price</p>
                <p className="prisText">1.63 wETH</p>
              </div>
              <div>
                <p className="priseText">Highest Bid</p>
                <p className="prisText">10.33 wETH</p>
              </div>
            </div>
          </div>
        </div>
        <div className="nftCard">
          <img src={nft2} alt="" />
          <div className="nftBot">
            <h1 className="DistantText">Distant Galaxy</h1>
            <img src={avatar2} alt="" />
            <div style={{ display: "flex", gap: "71px" }}>
              <div>
                <p className="priseText">Price</p>
                <p className="prisText">1.63 wETH</p>
              </div>
              <div>
                <p className="priseText">Highest Bid</p>
                <p className="prisText">10.33 wETH</p>
              </div>
            </div>
          </div>
        </div>
        <div className="nftCard">
          <img src={nft3} alt="" />
          <div className="nftBot">
            <h1 className="DistantText">Distant Galaxy</h1>
            <img src={avatar3} alt="" />
            <div style={{ display: "flex", gap: "71px" }}>
              <div>
                <p className="priseText">Price</p>
                <p className="prisText">1.63 wETH</p>
              </div>
              <div>
                <p className="priseText">Highest Bid</p>
                <p className="prisText">10.33 wETH</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button className="vievRankBtn vievRankBtn2">
            <img src={eyeic} alt="" />
            See All
          </button>
    </div>
  );
}

export default Discover;
