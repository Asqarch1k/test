import React from "react";
import "./hero.css";
import HighlightedNFT from "../../../imgs/HighlightedNFT.png";
function Hero() {
  return (
    <div className="heroSection">
      <div className="bigBox">
        <div>
          <h1 className="DiscoverText">
            Discover <br /> digital art & Collect NFTs
          </h1>
          <p className="NFTmarketplacetext">
            NFT marketplace UI created with Anima for <br /> Figma. Collect, buy
            and sell art from more <br /> than 20k NFT artists.
          </p>
        </div>
        <div className="rightFoto">
          <img src={HighlightedNFT} alt="" />
        </div>
      </div>
      <div>
        <button className="getStrBtn">Get started</button>
        <div className="numbersText">
          <div>
            <h3 className="numsText">240k+ </h3>
            <p className="numcText">Total Sale</p>
          </div>
          <div>
            <h3 className="numsText">100k+ </h3>
            <p className="numcText">Auctions</p>
          </div>
          <div>
            <h3 className="numsText">240k+ </h3>
            <p className="numcText">Artists</p>
          </div>
        </div>{" "}
      </div>
    </div>
  );
}

export default Hero;
