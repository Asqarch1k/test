import React from "react";
import "./footer.css";
import logo from "../../../imgs/Logo.png";
import DiscordLogo from "../../../imgs/DiscordLogo.png";
import TwitterLogo from "../../../imgs/TwitterLogo.png";
import InstagramLogo from "../../../imgs/InstagramLogo.png";
import YoutubeLogo from "../../../imgs/YoutubeLogo.png";

function Footer() {
  return (
    <div className="footer">
      <div className="wrapper">
        <div>
          <h1>
            <img src={logo} alt="" />
          </h1>
          <p className="footerTex">
            NFT marketplace UI created <br /> with Anima for Figma.
          </p>
          <p className="footerTex">Join our community</p>
          <div className="iconsdiv">
            <img src={DiscordLogo} alt="" />
            <img src={YoutubeLogo} alt="" />
            <img src={TwitterLogo} alt="" />
            <img src={InstagramLogo} alt="" />
          </div>
        </div>
        <div>
          <h1 className="mainTex">Explore</h1>
          <p className="footerTex">Marketplace</p>
          <p className="footerTex">Rankings</p>
          <p className="footerTex">Connect a wallet</p>
        </div>
        <div>
          <h1 className="mainTex">Join our weekly digest</h1>
          <p className="footerTex">
            Get exclusive promotions & updates <br /> straight to your inbox.
          </p>
          <div className="subscribe">
            <input
              className="inputSec"
              type="text"
              placeholder="Enter your email here Subscribe"
            />
            <button className="SubscribeBtn">Subscribe</button>
          </div>
        </div>
      </div>
      <hr />
      <p className="footerTex footerTex1">Ⓒ NFT Market. Use this template freely.</p>
    </div>
  );
}

export default Footer;
