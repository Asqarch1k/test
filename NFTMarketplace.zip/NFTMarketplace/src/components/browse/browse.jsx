import React from "react";
import "./browse.css";
import pick1 from "../../../imgs/Category Icon.png";
import pick2 from "../../../imgs/Category Icon (1).png";
import pick3 from "../../../imgs/Category Icon (2).png";
import pick4 from "../../../imgs/Category Icon (3).png";
import pick5 from "../../../imgs/Category Icon (4).png";
import pick6 from "../../../imgs/Category Icon (5).png";
import pick7 from "../../../imgs/Category Icon (6).png";
import pick8 from "../../../imgs/Category Icon (7).png";

function Browse() {
  return (
    <div className="browseSection">
      <h1 style={{ marginBottom: "25px", color: "#fff" }}>Browse Categories</h1>
      <div className="browseCarsd">
        <div className="boxes">
          <img src={pick1} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick2} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick3} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick4} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick5} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick6} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick7} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
        <div className="boxes">
          <img src={pick8} alt="" />
          <h4 className="cardText">Art</h4>
        </div>
      </div>
    </div>
  );
}

export default Browse;
